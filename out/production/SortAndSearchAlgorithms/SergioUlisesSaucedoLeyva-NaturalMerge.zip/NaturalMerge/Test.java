package NaturalMerge;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws Exception{

        String nameFile = "numbers.txt";
        FileWriter file_W = null;
        PrintWriter pw;
        int number;

        file_W = new FileWriter(nameFile);
        pw = new PrintWriter(file_W);
        for (int i=0 ; i<999; i++) {
            number = (int) (Math.random() * 2000);
            pw.println(number);
        }
        file_W.close();
        System.out.println("Numbers saved in file(numbers.txt)");

        System.out.println("sorting... This will take a while");
        NaturalMerge nm = new NaturalMerge(nameFile);
        nm.naturalMerge(0, nm.getNumLines()-1);
        System.out.println("The file has been sorted.");
    }

    static void write(File f) {
        int k;
        boolean more = true;
        DataInputStream stream = null;
        try {
            stream = new DataInputStream(new BufferedInputStream(new FileInputStream(f)));
            k = 0;
            System.out.println("FILE WITH INT CODES");
            while (more) {
                k++;
                System.out.print(stream.readInt() + " ");
                if (k % 11 == 0)
                    System.out.println();
            }
        } catch (EOFException eof) {
            System.out.println("\n *** End of File ***\n");
            try {
                stream.close();
            } catch (IOException er) {
                er.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
